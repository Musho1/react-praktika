function Loading(){
    return(
        <div className="spinerr">
                <div className="spinner-border text-danger spiner" role="status">
                    <span className="sr-only">Loading...</span>
                </div>
        </div>
    )
}
export default Loading