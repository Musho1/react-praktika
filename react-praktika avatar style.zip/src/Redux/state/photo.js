export default{
    loading:-1,
    photos:[],
    show:false,
    addDiv:true
}