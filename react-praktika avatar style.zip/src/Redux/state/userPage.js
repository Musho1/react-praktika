export default{
    userPageData:[],
    loadingUserPage:false,
}