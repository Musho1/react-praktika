export default{
    user:{
        isFetching: false,
        data: {},
        error: null,
    },
    userAuth:{
        isRequesting: false,
        error: null,
        isActive: false,
        uid: null,
    },
    start:false,
    startImg:false,
    loading:-1,
    avatar:"",
    isLod:false,
}