export default {
    sliderPhotos:[],
    sliderActive:false,
    sliderPhotosUSers:[]
}