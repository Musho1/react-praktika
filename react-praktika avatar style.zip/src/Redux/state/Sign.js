export default{
   login:{isRequest:false,error:null,errorMsg:""},
   signUp:{isRequest:false,error:null},
}