export const SliderActive=(value)=>{
    return{
        type:"sliderActive",
        value:value
    }
}